# Ponto de retorno da modernização visual

`App.jsx` nesta pasta é uma cópia de `src/App.jsx` imediatamente antes da modernização visual. Nenhum arquivo de página, componente, dado ou estilo antigo foi alterado nesta etapa.

Para desfazer apenas esta modernização, remover a linha `import './modernizacao.css';` de `src/App.jsx`. O arquivo `src/modernizacao.css` pode então ser removido. A cópia de `App.jsx` permite conferir o conteúdo anterior, mas não é necessário substituir todo o arquivo para desfazer.

Este ponto de retorno não desfaz as mudanças anteriores da conversa, como a logo oficial, a paleta de cores, os DAOs ou o comportamento da barra lateral.
