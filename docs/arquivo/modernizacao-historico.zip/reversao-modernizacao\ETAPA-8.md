# Ponto de retorno: cabeçalhos próximos nas outras páginas

Esta etapa aplicou ao Histórico e à Consulta de Medições o padrão de título e subtítulo próximos que já estava na Visão Geral.

Para desfazer somente esta extensão, restaure as classes dos elementos raiz e os textos `.titulo-secundario` a partir de `HistoricoMedicoes-antes-cabecalho-proximo.jsx` e `ConsultaMedicoes-antes-cabecalho-proximo.jsx` nesta pasta. Depois, remova `import './cabecalhos-proximos.css';` de `src/App.jsx`. A Visão Geral e as etapas anteriores permanecem.
