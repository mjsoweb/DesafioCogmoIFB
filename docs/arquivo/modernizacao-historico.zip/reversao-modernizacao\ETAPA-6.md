# Ponto de retorno: cabeçalhos compactos

Esta etapa voltou a colocar os nomes das páginas como títulos principais e moveu os textos em maiúsculas para os rótulos secundários. Também reduziu as fontes e alturas dos cabeçalhos.

Para voltar à apresentação da etapa 5, restaure apenas os blocos `.cabecalho-titulos` das cópias `VisaoGeral-antes-hierarquia-compacta.jsx`, `HistoricoMedicoes-antes-hierarquia-compacta.jsx` e `ConsultaMedicoes-antes-hierarquia-compacta.jsx` nesta pasta. Remova a linha `import './cabecalho-compacto.css';` de `src/App.jsx`. As demais camadas devem permanecer.
