# Ponto de retorno: cartões sem bordas coloridas

Esta etapa retirou as faixas decorativas coloridas dos cartões da Visão Geral, do resumo do Histórico e da tabela da Consulta. As bordas discretas e os estados de alerta continuam.

Para voltar a mostrar as faixas, remova apenas `import './cards-sem-acento-colorido.css';` de `src/App.jsx`.
