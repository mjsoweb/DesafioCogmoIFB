# Ponto de retorno: títulos principais

Esta etapa promoveu `PAINEL DE CONTROLE INTELIGENTE`, `ANÁLISE TEMPORAL` e `DADOS E REGISTROS` a títulos principais. Os nomes anteriores das páginas ficaram como rótulos secundários.

Para voltar ao visual anterior desta etapa, restaure apenas os blocos `.pagina-introducao` a partir das cópias `VisaoGeral-antes-titulos-principais.jsx`, `HistoricoMedicoes-antes-titulos-principais.jsx` e `ConsultaMedicoes-antes-titulos-principais.jsx` nesta pasta. Depois, remova a linha `import './titulos-principais.css';` de `src/App.jsx`. Evite substituir as páginas inteiras se elas receberem novas alterações.
