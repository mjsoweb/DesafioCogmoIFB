# Ponto de retorno: icones visiveis no menu recolhido

Os icones das paginas ficam visiveis com a barra lateral fechada. Clicar em um icone navega diretamente para a pagina sem abrir a barra. O botao de tres tracos continua sendo o unico controle de abertura no desktop.

Para voltar ao estado anterior desta etapa, adicione `.menu-lateral.ant-layout-sider-collapsed .menu-navegacao,` a lista de seletores que recebe `display: none` no inicio de `src/menu-por-clique.css`.
