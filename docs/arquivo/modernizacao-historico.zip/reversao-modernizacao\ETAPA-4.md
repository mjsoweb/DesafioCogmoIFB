# Ponto de retorno: tipografia refinada

A redução e o refinamento das fontes dos cabeçalhos das três páginas estão isolados em `src/tipografia-refinada.css`.

Para voltar à tipografia da etapa anterior, remova apenas `import './tipografia-refinada.css';` de `src/App.jsx`. Os textos, layouts e as outras camadas visuais permanecem iguais.
