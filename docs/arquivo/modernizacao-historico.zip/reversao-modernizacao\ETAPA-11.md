# Ponto de retorno: segundo título do Histórico

O subtítulo do filtro “Período e Estação” foi restaurado. Esta etapa retirou somente o texto “Histórico de Medições” ao lado do título principal “Análise temporal”.

Para voltar a exibir esse segundo título, copie o elemento `<Text className="titulo-secundario">Histórico de Medições</Text>` da cópia `HistoricoMedicoes-antes-retirada-subtitulo-filtro.jsx` para o bloco `.cabecalho-titulos` de `src/paginas/HistoricoMedicoes.jsx`.
