# Ponto de retorno: pequena folga no topo

Esta etapa colocou 8 px de espaço acima do cartão “Análise temporal” no desktop. Para voltar a deixá-lo encostado no topo, remova apenas `import './historico-folga-pequena.css';` de `src/App.jsx`.
