# Ponto de retorno: segunda modernização

A segunda modernização está toda em `src/modernizacao-extra.css`, carregado pela linha `import './modernizacao-extra.css';` em `src/App.jsx`.

Para voltar **somente** ao visual da primeira modernização que foi aprovado, remova essa linha de `src/App.jsx`. O arquivo `src/modernizacao-extra.css` pode ser excluído depois. Não remova `import './modernizacao.css';`, pois ele mantém a primeira modernização.

Esta etapa não altera componentes, dados, títulos nem a lógica dos gráficos. O arquivo anterior `reversao-modernizacao/LEIA-ME.md` continua documentando como voltar ao visual antes da primeira modernização.
