# Ponto de retorno: titulo do Historico em card

O bloco "Análise temporal" e sua descrição aparecem em um card branco compacto, com a mesma borda, cantos e sombra dos títulos da Visão Geral e da Consulta. O filtro continua ao lado em telas largas e abaixo em telas menores.

Para desfazer somente esta etapa, remova `import './historico-titulo-card.css';` de `src/App.jsx`.
