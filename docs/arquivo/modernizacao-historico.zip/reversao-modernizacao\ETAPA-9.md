# Ponto de retorno: inversão dos cabeçalhos compactos

Esta etapa inverteu os textos de `<Title>` e `.titulo-secundario` nas três páginas, sem mudar estilos ou componentes.

Para voltar à apresentação anterior, restaure somente esses dois textos nas páginas a partir das cópias `VisaoGeral-antes-inversao-compacta.jsx`, `HistoricoMedicoes-antes-inversao-compacta.jsx` e `ConsultaMedicoes-antes-inversao-compacta.jsx` nesta pasta. Não substitua as páginas inteiras caso tenham recebido outras alterações.
