# Ponto de retorno: Histórico sem folga no topo

Esta etapa retirou o espaço entre o topo da área principal e o cartão “Análise temporal” no desktop.

Para recuperar a folga anterior, remova apenas `import './historico-sem-folga-topo.css';` de `src/App.jsx`.
