# Ponto de retorno: filtros compactos do Histórico

O cartão “Período e Estação” ficou mais baixo e o grupo de filtros foi centralizado. A mudança está toda em `src/filtros-historico-compactos.css`.

Para voltar ao layout anterior do filtro, remova apenas `import './filtros-historico-compactos.css';` de `src/App.jsx`. As outras etapas continuam.
