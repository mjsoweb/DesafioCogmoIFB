# Ponto de retorno: botões externos na Consulta

Os botões “Exportar CSV” e “Atualizar” foram colocados novamente à direita do cabeçalho, fora do cartão de apresentação.

Para voltar a deixá-los dentro do cartão, restaure apenas o trecho `consulta-cabecalho` de `ConsultaMedicoes-antes-botoes-externos.jsx`, remova a classe `pagina-consulta` do elemento raiz e retire `import './botoes-consulta-externos.css';` de `src/App.jsx`.
