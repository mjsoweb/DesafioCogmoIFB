# Restaurar o cartão Estação Ativa

A cópia `VisaoGeral-antes-retirada-estacao.jsx` contém a página imediatamente antes da retirada do cartão. Para restaurar apenas o cartão, recoloque a declaração `estacaoAtual` e o bloco `.identificacao` dessa cópia em `src/paginas/VisaoGeral.jsx`. Evite substituir a página inteira caso tenha recebido outras alterações depois desta etapa.
