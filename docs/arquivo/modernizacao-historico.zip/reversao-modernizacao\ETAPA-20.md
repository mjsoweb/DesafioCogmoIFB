# Ponto de retorno: cartões de apresentação nas outras páginas

Esta etapa aplicou à Visão Geral e à Consulta de Medições o mesmo cartão de apresentação compacto do Histórico. Também retirou os rótulos secundários dessas duas páginas.

Para desfazer somente esta etapa, remova `import './apresentacao-card-outras-paginas.css';` de `src/App.jsx` e restaure a classe do elemento raiz e o elemento `.titulo-secundario` nas páginas usando `VisaoGeral-antes-card-apresentacao.jsx` e `ConsultaMedicoes-antes-card-apresentacao.jsx` desta pasta. Não substitua as páginas inteiras caso tenham recebido alterações posteriores.
