# Ponto de retorno: rotulos roxos

Os rotulos pequenos em caixa alta dos cards seguem o mesmo roxo de "ESTAÇÃO DE MONITORAMENTO". A alteracao inclui os rotulos do resumo e dos indicadores do Historico.

Para desfazer, remova `import './rotulos-roxos.css';` de `src/App.jsx`.
