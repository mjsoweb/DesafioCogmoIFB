# Ponto de retorno: gráficos lado a lado

Os cartões dos gráficos do Histórico agora ficam lado a lado a partir de 820 px de largura. Em telas mais estreitas, continuam empilhados para manter a leitura.

Para voltar ao ponto de quebra anterior, remova somente `import './historico-graficos-lado-a-lado.css';` de `src/App.jsx`.
