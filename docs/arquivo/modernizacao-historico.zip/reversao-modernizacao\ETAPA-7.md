# Ponto de retorno: cabeçalho próximo na Visão Geral

Esta etapa afetou somente a Visão Geral. Para voltar à versão anterior, restaure a classe do elemento raiz e o texto de `.titulo-secundario` a partir de `VisaoGeral-antes-cabecalho-proximo.jsx`. Em seguida, remova `import './visao-geral-proxima.css';` de `src/App.jsx`.

Não é necessário alterar as outras páginas ou camadas de estilo.
