# Ponto de retorno: menu lateral por clique

O menu lateral inicia recolhido no desktop. O botao de tres tracos o abre por clique, e o botao de fechar o recolhe. Passar o mouse nao altera mais o menu. No celular, o botao de abertura da pagina e o fechamento existentes continuam.

Para desfazer esta etapa, restaure `src/componentes/LayoutPrincipal.jsx` a partir de `reversao-modernizacao/LayoutPrincipal-antes-menu-por-clique.jsx`, remova `import './menu-por-clique.css';` de `src/App.jsx` e apague `src/menu-por-clique.css`.
