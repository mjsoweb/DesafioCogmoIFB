# Ponto de retorno: cabeçalho do Histórico como cartão

Esta etapa colocou “Análise temporal” no mesmo padrão visual dos outros cartões: largura da página, borda discreta, cantos arredondados e sombra leve.

Para voltar à faixa branca com borda vermelha em largura total, remova apenas `import './cabecalho-historico-card.css';` de `src/App.jsx`.
