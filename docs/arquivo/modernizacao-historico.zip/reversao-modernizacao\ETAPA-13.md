# Ponto de retorno: barra do Histórico em toda a largura

Esta etapa fez a barra roxa ocupar todo o topo da área principal, até as bordas. O ajuste está em `src/barra-historico-total.css`.

Para voltar à barra anterior, menor e arredondada, remova apenas `import './barra-historico-total.css';` de `src/App.jsx`. A etapa 12 e os demais ajustes permanecem.
