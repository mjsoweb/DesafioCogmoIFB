# Ponto de retorno: logo recolhida e fechamento ao clicar fora

A logo fica visivel acima do botao de tres tracos quando a barra lateral esta fechada. Com a barra aberta, um clique fora dela a fecha. Os icones continuam navegando sem abrir a barra.

Para desfazer somente esta etapa, restaure `src/componentes/LayoutPrincipal.jsx` de `reversao-modernizacao/LayoutPrincipal-antes-clique-fora.jsx` e `src/menu-por-clique.css` de `reversao-modernizacao/menu-por-clique-antes-logo.css`.
